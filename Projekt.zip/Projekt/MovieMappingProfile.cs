﻿using AutoMapper;
using Projekt.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekt
{
    public class MovieMappingProfile : Profile
    {
        public MovieMappingProfile()
        {
            
        }
    }
}
